SELECT k.ad, t.konu, t.durum
FROM Kullanici k JOIN Talep t ON k.kullanici_id=t.kullanici_id;

SELECT * FROM Talep ORDER BY olusturma_tarihi DESC;

SELECT durum, COUNT(*) FROM Talep GROUP BY durum;

SELECT kullanici_id FROM Talep
GROUP BY kullanici_id HAVING COUNT(*)>1;

SELECT * FROM Talep
WHERE talep_id NOT IN (SELECT talep_id FROM Cevap);

SELECT personel_id, COUNT(*) FROM Cevap GROUP BY personel_id;

SELECT ad FROM Kullanici
WHERE kullanici_id=(
    SELECT kullanici_id FROM Talep
    GROUP BY kullanici_id
    ORDER BY COUNT(*) DESC LIMIT 1
);

SELECT d.departman_adi, k.ad
FROM Departman d
JOIN DestekPersoneli dp ON d.departman_id=dp.departman_id
JOIN Kullanici k ON dp.kullanici_id=k.kullanici_id;

SELECT * FROM Talep ORDER BY olusturma_tarihi DESC LIMIT 5;

SELECT personel_id FROM DestekPersoneli
WHERE personel_id NOT IN (
    SELECT DISTINCT personel_id FROM Cevap
);

CREATE VIEW vw_KullaniciTalepler AS
SELECT k.ad, t.konu, t.durum
FROM Kullanici k JOIN Talep t ON k.kullanici_id=t.kullanici_id;

CREATE VIEW vw_AcikTalepler AS
SELECT * FROM Talep WHERE durum='Açık';

CREATE VIEW vw_PersonelCevaplari AS
SELECT personel_id, COUNT(*) AS cevap_sayisi
FROM Cevap GROUP BY personel_id;

DELIMITER $$

CREATE PROCEDURE TalepEkle(
    IN p_kullanici_id INT,
    IN p_konu VARCHAR(100),
    IN p_aciklama TEXT
)
BEGIN
    INSERT INTO Talep (kullanici_id,konu,aciklama)
    VALUES (p_kullanici_id,p_konu,p_aciklama);
END$$

CREATE PROCEDURE TalepDurumGuncelle(
    IN p_talep_id INT,
    IN p_durum VARCHAR(20)
)
BEGIN
    UPDATE Talep SET durum=p_durum WHERE talep_id=p_talep_id;
END$$

CREATE PROCEDURE CevapEkle(
    IN p_talep_id INT,
    IN p_personel_id INT,
    IN p_mesaj TEXT
)
BEGIN
    INSERT INTO Cevap (talep_id,personel_id,mesaj)
    VALUES (p_talep_id,p_personel_id,p_mesaj);
END$$

DELIMITER ;

START TRANSACTION;
INSERT INTO Talep (kullanici_id,konu,aciklama)
VALUES (2,'Mail Sorunu','Mail gelmiyor');
COMMIT;

START TRANSACTION;
UPDATE Talep SET durum='Kapalı' WHERE talep_id=999;
ROLLBACK;

START TRANSACTION;
INSERT INTO Cevap (talep_id,personel_id,mesaj)
VALUES (1,1,'Sorun çözüldü');
UPDATE Talep SET durum='Kapalı' WHERE talep_id=1;
COMMIT;