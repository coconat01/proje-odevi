
CREATE DATABASE IF NOT EXISTS destek_sistemi;
USE destek_sistemi;

CREATE TABLE Kullanici (
    kullanici_id INT AUTO_INCREMENT PRIMARY KEY,
    ad VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    rol ENUM('Kullanici','Destek') NOT NULL,
    kayit_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE Departman (
    departman_id INT AUTO_INCREMENT PRIMARY KEY,
    departman_adi VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE DestekPersoneli (
    personel_id INT AUTO_INCREMENT PRIMARY KEY,
    kullanici_id INT NOT NULL UNIQUE,
    departman_id INT NOT NULL,
    FOREIGN KEY (kullanici_id) REFERENCES Kullanici(kullanici_id),
    FOREIGN KEY (departman_id) REFERENCES Departman(departman_id)
);

CREATE TABLE Talep (
    talep_id INT AUTO_INCREMENT PRIMARY KEY,
    kullanici_id INT NOT NULL,
    konu VARCHAR(100) NOT NULL,
    aciklama TEXT NOT NULL,
    durum VARCHAR(20) DEFAULT 'Açık',
    olusturma_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP,
    CHECK (durum IN ('Açık','İşlemde','Kapalı')),
    FOREIGN KEY (kullanici_id) REFERENCES Kullanici(kullanici_id)
);

CREATE TABLE Cevap (
    cevap_id INT AUTO_INCREMENT PRIMARY KEY,
    talep_id INT NOT NULL,
    personel_id INT NOT NULL,
    mesaj TEXT NOT NULL,
    cevap_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (talep_id) REFERENCES Talep(talep_id),
    FOREIGN KEY (personel_id) REFERENCES DestekPersoneli(personel_id)
);

CREATE TABLE Log (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    tablo_adi VARCHAR(50),
    islem VARCHAR(20),
    islem_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP,
    detay TEXT
);

INSERT INTO Kullanici (ad,email,rol) VALUES
('Ali Yılmaz','ali@mail.com','Kullanici'),
('Ayşe Demir','ayse@mail.com','Kullanici'),
('Mehmet Kaya','mehmet@mail.com','Destek'),
('Zeynep Arslan','zeynep@mail.com','Destek');

INSERT INTO Departman (departman_adi) VALUES
('Bilgi İşlem'),
('Yazılım Destek');

INSERT INTO DestekPersoneli (kullanici_id,departman_id) VALUES
(3,1),
(4,2);

INSERT INTO Talep (kullanici_id,konu,aciklama,durum) VALUES
(1,'İnternet Sorunu','Bağlantı kopuyor','Açık'),
(2,'Bilgisayar Açılmıyor','Mavi ekran hatası','İşlemde'),
(1,'Yazıcı Sorunu','Çıktı almıyor','Açık');

INSERT INTO Cevap (talep_id,personel_id,mesaj) VALUES
(1,1,'Modemi yeniden başlatın'),
(2,2,'Kontrol ediliyor');
